# VHOS Framework — reference implementation v0.1.0

Working code and worked example for the **VHOS Unified Specification
v3.0** (see `Spec/VHOS_v3_unified.pdf`). Python 3.10+, standard
library only. First subject instantiated: **Alan Turing**.

## Quickstart

    # compile the Turing HDL -> Contract 2 projections
    python3 -m vhos.hdl.compiler subjects/alan_turing

    # run the closed affect loop, watch what an engine would receive
    python3 scripts/demo_loop.py
    #   live, with LM Studio serving your chosen model (see LIVE-TEST-GUIDE.pdf):
    python3 scripts/demo_loop.py --adapter lmstudio

    # A/B: same question, different bodily state (the Tier-2 experiment)
    python3 scripts/ask_turing.py --state calm     --prompt "Can machines think?" --seed 11
    python3 scripts/ask_turing.py --state stressed --prompt "Can machines think?" --seed 11

    # run the test suite (32 tests)
    python3 -m unittest discover -s tests

    # verify archive integrity
    python3 -m vhos.archive.manifest subjects/alan_turing --verify

    # (operator, once) fetch full source texts into raw/
    python3 scripts/fetch_sources.py --all

    # package everything for transfer to the AI machine
    python3 scripts/package_bundle.py

## What is implemented, mapped to the spec

| spec part | artifact | status |
|---|---|---|
| Appendix A vocabulary | `vhos/vocabulary.json` + loader (220 words, intensity-split rule) | done, tested |
| Part II HDL grammar | `vhos/hdl/parser.py` — assertions, conditionals, chains, annotations, blocks | done, tested (parses the spec's own Einstein example verbatim) |
| Contract 2 rules | `vhos/hdl/validator.py` — E001–E007, W001–W004; self-authority immutable flags | done, tested |
| Heuristics projection | `vhos/hdl/projection.py` — the published mapping table; authored-wins + sync report | done, tested |
| Contract 1 archive | `vhos/archive/` — scaffold, SHA-256 manifest, verify | done |
| Contract 3 substrate | `vhos/substrate/` — interface + mock, LM Studio, and Ollama adapters | done (LM Studio is the live-test engine, ADR-005) |
| SOMA (new in this repo) | `vhos/soma/` — state, leaky-integrator dynamics, appraisal, Tier 1+2 coupling | done, tested — see `docs/soma-design-v0.1.md` |
| General Affect Model / Personal Tuning | `vhos/affect/` — substrate-free reference implementations | done (v0 linear/lexical baselines) |
| RUNTIME assembly | `vhos/runtime/assemble.py` — persona + affect + Part VIII disclosure line | done |
| Worked subject | `subjects/alan_turing/` — MATERIAL with verification ladder, 21-statement HDL, fingerprint, divergence map, priors-only soma | done, compiles clean |

## Layout

    Spec/                  the specification PDF (authoritative document)
    docs/                  soma design v0.1 · compiler design · capture guide
    docs/decisions/        ADR-001..004 (language, coupling, corpus, vocabulary)
    vhos/                  the package (stdlib-only core)
    subjects/alan_turing/  Contract 1 archive + HDL + derived projections
    scripts/               demo_loop.py · fetch_sources.py
    tests/                 32 unit/integration tests
    examples/              demo transcript + soma trace CSV

## Honesty section (in the spirit of spec Parts VI–VII)

The affect readout and tuning matcher are transparent v0 baselines
(linear/lexical), meant to be beaten by learned models once
synchronized capture data exists. No claim is made that any of this
produces feeling; the claim is functional and testable — see the
ablation protocol in `docs/soma-design-v0.1.md` §9. The Turing
instance has no interview and no biometrics and its fidelity ceiling
is capped accordingly, in the archive itself. Four authored-vs-derived
projection gaps are currently open in the compile report — visible on
purpose (report, never silently prefer).

## Transferring to the AI machine

The framework is self-contained (stdlib-only, no install step) and
moves as one folder. `python3 scripts/package_bundle.py` verifies the
archive, zips everything into `dist/` with a SHA-256, and
**LIVE-TEST-GUIDE.pdf** (repo root) walks the whole transfer, LM Studio
setup, and experiment protocol step by step.

## Near-term roadmap

1. Live LM Studio run of the demo and the calm/stressed A/B — Tier 2
   visibly changing output (LIVE-TEST-GUIDE.pdf; in progress).
2. Retrieval over raw/ with the mood-congruence weight (v3.1 recall).
3. Held-out evaluation harness: affect-on vs. affect-off ablation.
4. Second subject: a LIVING one — self-authored statements, real
   sessions/, first true soma calibration. The spec's actual purpose.
