"""LM Studio adapter — local engine via the OpenAI-compatible API.

LM Studio (lmstudio.ai) serves whatever model the operator has loaded
at http://localhost:1234 with OpenAI-compatible endpoints; since
LM Studio 0.4.x a native REST API also exists at /api/v1/*.  This
adapter targets the OpenAI-compatible surface because it is the most
durable local-API shape in the ecosystem (ADR-005):

    GET  /v1/models             -> list loaded/available model ids
    POST /v1/chat/completions   -> generation (system + user messages)
    POST /v1/embeddings         -> embeddings (if an embedding model is loaded)

The operator chooses the model inside LM Studio; if --model is not
given, the adapter uses the first id reported by /v1/models.

Adapters are DISPOSABLE by design (spec Part I): stdlib HTTP only,
nothing upstream knows this file exists.
"""

import json
import urllib.request
import urllib.error

from ..contract import Substrate, CapabilityReport, GenParams

DEFAULT_HOST = "http://localhost:1234"


class LMStudioSubstrate(Substrate):

    def __init__(self, model=None, host=DEFAULT_HOST, timeout=300):
        self.model = model            # None -> first loaded model
        self.host = host.rstrip("/")
        self.timeout = timeout

    # ------------------------------------------------------------------
    def _get(self, path, timeout=None):
        req = urllib.request.Request(self.host + path)
        with urllib.request.urlopen(req, timeout=timeout or self.timeout) as r:
            return json.loads(r.read().decode("utf-8"))

    def _post(self, path, payload):
        req = urllib.request.Request(
            self.host + path,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json",
                     "Authorization": "Bearer lm-studio"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=self.timeout) as r:
            return json.loads(r.read().decode("utf-8"))

    def _models(self, timeout=4):
        out = self._get("/v1/models", timeout=timeout)
        return [m.get("id", "?") for m in out.get("data", [])]

    def _resolve_model(self):
        if self.model:
            return self.model
        models = self._models()
        if not models:
            raise RuntimeError(
                "LM Studio is running but no model is loaded. Load one in "
                "the LM Studio window (or the Developer > Server tab), "
                "then retry.")
        self.model = models[0]
        return self.model

    # ------------------------------------------------------------------
    def capabilities(self):
        try:
            models = self._models()
            ok = True
        except (urllib.error.URLError, OSError, ValueError):
            models, ok = [], False
        return CapabilityReport(
            name="lmstudio:%s" % (self.model or (models[0] if models else "?")),
            available=ok,
            modalities=["text"],
            supports_affect=False,          # affect math is runtime-side
            supports_affect_recall=False,
            versions={"adapter": "0.1.0", "api": "openai-compat"},
            limits={"host": self.host, "models_visible": models},
        )

    def generate(self, prompt, corpus, persona, affect, params: GenParams) -> str:
        payload = {
            "model": None,   # filled below
            "messages": [
                {"role": "system",
                 "content": persona if isinstance(persona, str) else str(persona)},
                {"role": "user", "content": prompt},
            ],
            "temperature": params.temperature,
            "top_p": params.top_p,
            "max_tokens": params.max_tokens,
            "stream": False,
        }
        if params.seed is not None:
            payload["seed"] = params.seed
        try:
            payload["model"] = self._resolve_model()
            out = self._post("/v1/chat/completions", payload)
        except (urllib.error.URLError, OSError) as e:
            raise RuntimeError(
                "LM Studio not reachable at %s (%s).\n"
                "  1. Open LM Studio and load your chosen model\n"
                "  2. Developer tab -> Start Server (default port 1234)\n"
                "  3. If you changed the port, pass --host http://localhost:<port>"
                % (self.host, e))
        choices = out.get("choices") or []
        if not choices:
            raise RuntimeError("LM Studio returned no choices: %s"
                               % json.dumps(out)[:400])
        return (choices[0].get("message") or {}).get("content", "")

    def recall(self, query, scope, affect=None):
        # v0: retrieval is runtime-side (roadmap step 2).
        return []

    def reason(self, context, question):
        text = self.generate(
            prompt="Context:\n%s\n\nQuestion: %s\nAnswer with a conclusion "
                   "and a short rationale." % (context, question),
            corpus=None, persona="You are a careful reasoner.",
            affect=None, params=GenParams(temperature=0.2, max_tokens=400))
        return {"conclusion": text.strip(), "rationale": "see conclusion"}

    def embed(self, text):
        try:
            out = self._post("/v1/embeddings",
                             {"model": self._resolve_model(), "input": text})
            data = out.get("data") or []
            return data[0].get("embedding", []) if data else []
        except (urllib.error.URLError, OSError, RuntimeError):
            return []
