"""RUNTIME — persona assembly.

Translates compiled HDL statements + the current AffectState into the
system context a substrate receives through the Abstraction Contract.
Different runtimes may emphasize different aspects of the subject
without modifying the underlying description (spec Part I); this is
the reference text-runtime assembly.

The disclosure default (spec Part VIII) is embedded in the frame line:
the output is identifiable as a model, not the person.
"""

def _second_person(stimulus):
    """HDL stimuli are written for 'WHEN THIS SUBJECT <verb>s ...';
    convert the leading verb to second person.  Heuristic on purpose —
    authors should keep stimuli simple (compiler doc §authoring)."""
    words = stimulus.split()
    if not words:
        return stimulus
    v = words[0]
    if v == "is":
        words[0] = "are"
    elif v.endswith("ies"):
        words[0] = v[:-3] + "y"
    elif v.endswith("s") and not v.endswith("ss"):
        words[0] = v[:-1]
    return " ".join(words)


VERB_TEMPLATES = {
    "VALUES": "You value {o}.",
    "BELIEVES": "You believe {o}.",
    "FEARS": "You fear {o}.",
    "TRUSTS": "You trust {o}.",
    "PREFERS": "You prefer {o}.",
    "DECIDES": "You decide {o}.",
    "WEIGHS": "You give unusual weight to {o}.",
    "DISCOUNTS": "You habitually under-weigh {o}.",
    "ANCHORS_ON": "You anchor your first estimates on {o}.",
    "DEFAULTS_TO": "When uncertain, you default to {o}.",
    "IS_SWAYED_BY": "You are susceptible to {o}.",
    "RESISTS": "You push back against {o}.",
    "FRAMES": "You frame {o}.",
    "HOPES": "You hope {o}.",
    "IDENTIFIES_AS": "You identify as {o}.",
    "REJECTS": "You reject {o}.",
}

INTENSITY_ADVERB = {"strongly": " This runs deep.",
                    "weakly": " This is mild.",
                    "moderately": "",
                    "always": " Always.",
                    "occasionally": " Sometimes.",
                    "rarely": " Rarely, but truly.",
                    None: ""}

LAYER_ORDER = ("drives", "social", "heuristics", "narrative")
LAYER_TITLES = {"drives": "What moves you",
                "social": "How you are with people",
                "heuristics": "How you decide",
                "narrative": "The story you tell about yourself"}


def assemble_system_prompt(subject_name, statements, affect_state=None,
                           interoception="", min_confidence=0.55,
                           max_per_layer=6):
    """statements: list of Contract 2 dicts (from statements.json)."""
    lines = []
    lines.append(
        "You are a modeled approximation of %s, produced under the VHOS "
        "specification. You are a model built from captured data and "
        "authored description — not the person, and you do not claim to "
        "be. Within that frame, embody the description below faithfully."
        % subject_name)
    lines.append("")

    by_layer = {}
    chains = []
    for s in statements:
        if s["form"] == "assertion":
            if s["confidence"] >= min_confidence:
                by_layer.setdefault(s["layer"], []).append(s)
        else:
            chains.append(s)

    for layer in LAYER_ORDER:
        group = sorted(by_layer.get(layer, []),
                       key=lambda x: -x["confidence"])[:max_per_layer]
        if not group:
            continue
        lines.append("## " + LAYER_TITLES[layer])
        for s in group:
            tmpl = VERB_TEMPLATES.get(s["verb"], "You {v} {o}.")
            sentence = tmpl.format(o=s["object"], v=str(s["verb"]).lower())
            sentence += INTENSITY_ADVERB.get(s["intensity"], "")
            lines.append("- " + sentence)
        lines.append("")

    if chains:
        lines.append("## Characteristic sequences")
        for s in chains:
            steps = []
            for word, side in zip(s["chain"], s["chain_sides"]):
                pre = {"feel": "you feel", "become": "you become",
                       "act": "you act"}[side]
                steps.append("%s %s" % (pre, word))
            lines.append("- When you %s: %s."
                         % (_second_person(s["stimulus"]), ", then ".join(steps)))
        lines.append("")

    if affect_state is not None:
        lines.append("## Current constructed state")
    